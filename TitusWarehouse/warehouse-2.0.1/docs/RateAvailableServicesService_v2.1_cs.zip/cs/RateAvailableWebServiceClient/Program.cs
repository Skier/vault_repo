using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services.Protocols;
using RateAvailableWebServiceClient.RateAvailableServicesWebReference;

//
// Sample code to call Rate Availabe Web Service
//

namespace RateAvailableWebServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            // Build a RateAvailableServices request object
            RateAvailableServicesRequest request = new RateAvailableServicesRequest();
            //
            request.WebAuthenticationDetail = new WebAuthenticationDetail();
            request.WebAuthenticationDetail.UserCredential = new WebAuthenticationCredential();
            request.WebAuthenticationDetail.UserCredential.Key = "XXX"; // Replace "XXX" with the Key
            request.WebAuthenticationDetail.UserCredential.Password = "XXX"; // Replace "XXX" with the Password
            //
            request.ClientDetail = new ClientDetail();
            request.ClientDetail.AccountNumber = "XXX"; // Replace "XXX" with clients account number
            request.ClientDetail.MeterNumber = "XXX"; // Replace "XXX" with clients meter number
            //
            request.TransactionDetail = new TransactionDetail();
			request.TransactionDetail.CustomerTransactionId = "***Rate Available v3 Request using VC#***"; // This is a reference field for the customer.  Any value can be used and will be provided in the response.
            //
            request.Version = new VersionId(); // WSDL version information, value is automatically set from wsdl            
            //
            request.Origin = new Address(); // Origin information
            request.Origin.StreetLines = new string[1] { "Address Line 1" };            
            request.Origin.City = "City Name";
            request.Origin.StateOrProvinceCode = "TX";            
            request.Origin.PostalCode = "73301";            
            request.Origin.CountryCode = "US";
            //
            request.Destination = new Address(); // Destination information
            request.Destination.StreetLines = new string[1] { "Address Line 1" };            
            request.Destination.City = "City Name";            
            request.Destination.StateOrProvinceCode = "TN";
            request.Destination.PostalCode = "38133";
            request.Destination.CountryCode = "US";
            //
            request.CurrencyType = "USD"; 
            request.DropoffType = DropoffType.REGULAR_PICKUP; // Dropoff Types are BUSINESS_SERVICE_CENTER, DROP_BOX, REGULAR_PICKUP, REQUEST_COURIER, STATION
            request.DropoffTypeSpecified = true;
            request.ShipDate = DateTime.Now; // Shipping date and time
            request.RateRequestTypes = new RateRequestType[1] { RateRequestType.ACCOUNT}; // Request options are: ACCOUNT, LIST
            //
            request.RateRequestPackageSummary = new RateRequestPackageSummary(); // package summary
            request.RateRequestPackageSummary.PieceCount = "1";
            request.RateRequestPackageSummary.TotalWeight = new Weight();
            request.RateRequestPackageSummary.TotalWeight.Value = 20;
            request.RateRequestPackageSummary.TotalWeight.Units = WeightUnits.LB;
            request.RateRequestPackageSummary.PerPieceDimensions = new Dimensions();
            request.RateRequestPackageSummary.PerPieceDimensions.Length = "20";
            request.RateRequestPackageSummary.PerPieceDimensions.Width = "20";
            request.RateRequestPackageSummary.PerPieceDimensions.Height = "20";
            request.RateRequestPackageSummary.PerPieceDimensions.Units = LinearUnits.IN;
            request.RateRequestPackageSummary.SpecialServicesRequested = new PackageSpecialServicesRequested();
            // Type of special services are DANGEROUS_GOODS, APPOINTMENT_DELIVERY, ...
            request.RateRequestPackageSummary.SpecialServicesRequested.SpecialServiceTypes = new PackageSpecialServiceType[1]{ PackageSpecialServiceType.DANGEROUS_GOODS };            
            request.RateRequestPackageSummary.SpecialServicesRequested.DangerousGoodsDetail = new DangerousGoodsDetail();
            request.RateRequestPackageSummary.SpecialServicesRequested.DangerousGoodsDetail.Accessibility = DangerousGoodsAccessibilityType.ACCESSIBLE;
            request.RateRequestPackageSummary.SpecialServicesRequested.DangerousGoodsDetail.AccessibilitySpecified = true;
            // Type of dangerous goods accessibilities are ACCESSIBLE, INACCESSIBLE
            //
            RateService service = new RateService(); // Initialize the service
            //
            try
            {
                RateAvailableServicesReply reply = service.rateAvailableServices(request); // Service call
                if ((reply.HighestSeverity != NotificationSeverityType.ERROR) && (reply.HighestSeverity != NotificationSeverityType.FAILURE))// check if the call was successful
                {
                    foreach (RateAndServiceOptions option in reply.Options)
                    {
                        //This is service details
                        Console.WriteLine("-- Service details --");
                        Console.WriteLine("Delivery date {0} day {1}", option.ServiceDetail.DeliveryDate, option.ServiceDetail.DeliveryDay);
                        Console.WriteLine("Destination station id {0}", option.ServiceDetail.DestinationStationId);
                        Console.WriteLine("Packaging type {0} service type {1}", option.ServiceDetail.PackagingType, option.ServiceDetail.ServiceType);
                        Console.WriteLine("Transit time {0}", option.ServiceDetail.TransitTime);
                        foreach (RatedShipmentDetail ratedShipmentDetail in option.RatedShipmentDetails)
                        {
                            if(ratedShipmentDetail.ShipmentRateDetail.TotalBillingWeight!=null )
                                Console.WriteLine("Total billing weight {0} {1}", ratedShipmentDetail.ShipmentRateDetail.TotalBillingWeight.Units, ratedShipmentDetail.ShipmentRateDetail.TotalBillingWeight.Units);
                            if (ratedShipmentDetail.ShipmentRateDetail.TotalDimWeight != null)
                                Console.WriteLine("Total dim weight {0} {1}", ratedShipmentDetail.ShipmentRateDetail.TotalDimWeight.Value, ratedShipmentDetail.ShipmentRateDetail.TotalDimWeight.Units);
                            if (ratedShipmentDetail.ShipmentRateDetail.TotalFreightDiscounts != null)
                                Console.WriteLine("Total freight discount {0} {1}", ratedShipmentDetail.ShipmentRateDetail.TotalFreightDiscounts.Amount, ratedShipmentDetail.ShipmentRateDetail.TotalFreightDiscounts.Currency);
                            if (ratedShipmentDetail.ShipmentRateDetail.TotalNetCharge != null)
                                Console.WriteLine("Total net charge", ratedShipmentDetail.ShipmentRateDetail.TotalNetCharge.Amount, ratedShipmentDetail.ShipmentRateDetail.TotalNetCharge.Currency);
                            if (ratedShipmentDetail.ShipmentRateDetail.TotalNetFreight != null)
                                Console.WriteLine("Total net freight", ratedShipmentDetail.ShipmentRateDetail.TotalNetFreight.Amount, ratedShipmentDetail.ShipmentRateDetail.TotalNetFreight.Currency);
                            if (ratedShipmentDetail.ShipmentRateDetail.TotalSurcharges != null)
                                Console.WriteLine("Total surcharges {0} {1}", ratedShipmentDetail.ShipmentRateDetail.TotalSurcharges.Amount, ratedShipmentDetail.ShipmentRateDetail.TotalSurcharges.Currency);
                            if (null != ratedShipmentDetail.RatedPackages)
                            {
                                Console.WriteLine("--- Rated package detail ---");
                                foreach (RatedPackageDetail package in ratedShipmentDetail.RatedPackages) // This is package details
                                {
                                    Console.WriteLine("-- Rated packages --");
                                    Console.WriteLine("");
                                    if (null != package.PackageRateDetail.BillingWeight)
                                        Console.WriteLine("Billing weight {0} {1}", package.PackageRateDetail.BillingWeight.Value, package.PackageRateDetail.BillingWeight.Units);
                                    if (null != package.PackageRateDetail.DimWeight)
                                        Console.WriteLine("Dim weight {0} {1}", package.PackageRateDetail.DimWeight.Value, package.PackageRateDetail.DimWeight.Units);
                                    if (null != package.PackageRateDetail.BaseCharge)
                                        Console.WriteLine("Base charge {0} {1}", package.PackageRateDetail.BaseCharge.Amount, package.PackageRateDetail.BaseCharge.Currency);
                                    if (null != package.PackageRateDetail.NetCharge)
                                        Console.WriteLine("Net charge {0} {1}", package.PackageRateDetail.NetCharge.Amount, package.PackageRateDetail.NetCharge.Currency);
                                    if (null != package.PackageRateDetail.NetFreight)
                                        Console.WriteLine("Net freight {0} {1}", package.PackageRateDetail.NetFreight.Amount, package.PackageRateDetail.NetFreight.Currency);
                                    if (null != package.PackageRateDetail.TotalSurcharges)
                                        Console.WriteLine("Total surcharges {0} {1}", package.PackageRateDetail.TotalSurcharges.Amount, package.PackageRateDetail.TotalSurcharges.Currency);
                                    if (null != package.PackageRateDetail.TotalFreightDiscounts)
                                        Console.WriteLine("Total freight discount {0} {1}", package.PackageRateDetail.TotalFreightDiscounts.Amount, package.PackageRateDetail.TotalFreightDiscounts.Currency);
                                }
                            }
                        }
                       
                    }
                }
                else
                {
                    Console.WriteLine(reply.Notifications[0].Message);
                }
            }
            catch (SoapException e)
            {
                Console.WriteLine(e.Detail.InnerText);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("Press any key to quit !");
            Console.ReadKey();
        }
    }
}

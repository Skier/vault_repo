using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml.Serialization;
using RatingWebServiceClient.RateServiceWebReference; // Web Reference

//
// Sample code to call the FedEx Rating Web Service
//

namespace RatingWebServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            // Build a RateRequest object
            RateRequest request = new RateRequest();
			//
            request.WebAuthenticationDetail = new WebAuthenticationDetail();
            request.WebAuthenticationDetail.UserCredential = new WebAuthenticationCredential();
            request.WebAuthenticationDetail.UserCredential.Key = "XXX"; // Replace "XXX" with the Key
            request.WebAuthenticationDetail.UserCredential.Password = "XXX"; // Replace "XXX" with the Password
            //
            request.ClientDetail = new ClientDetail();
            request.ClientDetail.AccountNumber = "XXX"; // Replace "XXX" with clients account number
            request.ClientDetail.MeterNumber = "XXX"; // Replace "XXX" with clients meter number
            //
            request.TransactionDetail = new TransactionDetail();
            request.TransactionDetail.CustomerTransactionId = "***Rate v3 Request using VC#***"; // This is a reference field for the customer.  Any value can be used and will be provided in the response.
            //
            request.Version = new VersionId(); // WSDL version information, value is automatically set from wsdl            
            // 
		    request.Origin = new Address();   // Origin information
            request.Origin.StreetLines = new string[1] { "Sender Address Line 1" };            
            request.Origin.City = "Sender City";
            request.Origin.StateOrProvinceCode = "TN";
            request.Origin.PostalCode = "38115";
            request.Origin.CountryCode = "US";
			//
            request.Destination = new Address(); // Destination Information
            request.Destination.StreetLines = new string[1] { "Recipient Address Line 1" };            
            request.Destination.City = "Recipient City";
            request.Destination.StateOrProvinceCode = "PQ";
            request.Destination.PostalCode = "H1E1A1";
            request.Destination.CountryCode = "CA";
            //
            request.Payment = new Payment(); // Payment Information
            request.Payment.PaymentType = PaymentType.SENDER; // Payment options are RECIPIENT, SENDER, THIRD_PARTY
            request.Payment.PaymentTypeSpecified = true;
            request.Payment.Payor = new Payor();
            request.Payment.Payor.AccountNumber = "XXX"; // Replace "XXX" with clients account number
            request.DropoffType = DropoffType.REGULAR_PICKUP; //Drop off types are BUSINESS_SERVICE_CENTER, DROP_BOX, REGULAR_PICKUP, REQUEST_COURIER, STATION
            request.ServiceType = ServiceType.INTERNATIONAL_PRIORITY; // Service types are STANDARD_OVERNIGHT, PRIORITY_OVERNIGHT, FEDEX_GROUND ...
            request.PackagingType = PackagingType.YOUR_PACKAGING; // Packaging type FEDEX_BOK, FEDEX_PAK, FEDEX_TUBE, YOUR_PACKAGING, ...
            request.ShipDate = DateTime.Now; // Shipping date and time
            //
            // COD details other than Collection Amount belong at the Shipment level
            request.SpecialServicesRequested = new ShipmentSpecialServicesRequested();
            request.SpecialServicesRequested.SpecialServiceTypes = new ShipmentSpecialServiceType[1];
            request.SpecialServicesRequested.SpecialServiceTypes[0] = ShipmentSpecialServiceType.COD;
            request.SpecialServicesRequested.CodDetail = new CodDetail();
            request.SpecialServicesRequested.CodDetail.CollectionType = CodCollectionType.GUARANTEED_FUNDS;
            request.SpecialServicesRequested.CodCollectionAmount = new Money();
            request.SpecialServicesRequested.CodCollectionAmount.Amount = 100;
            request.SpecialServicesRequested.CodCollectionAmount.Currency = "USD";
            //
            // The RateRequest.Items is a choice of one of the following:
            //
            // Array of RateRequestPackageSummary - Details of multi piece shipment rate request - Use this to rate a total piece total weight shipment.
            // Array of RateRequestPackageDetail - Details of simgle piece shipment rate request - Currently only 1 occurance is supported.
            //
            // Not passing one of these choices will result in "Schema Validation Failure", as one of these objects is required.
            //
            bool bPassRateRequestPackageSummary = true;
            //
            if (bPassRateRequestPackageSummary)
            {
                // -----------------------------------------
                // Passing multi piece shipment rate request
                // -----------------------------------------
                request.Items = new RateRequestPackageSummary[1] { new RateRequestPackageSummary() };
                //
                ((RateRequestPackageSummary)request.Items[0]).TotalWeight = new Weight();
                ((RateRequestPackageSummary)request.Items[0]).TotalWeight.Value = 20.0M;
                ((RateRequestPackageSummary)request.Items[0]).TotalWeight.Units = WeightUnits.LB;
                //
                ((RateRequestPackageSummary)request.Items[0]).TotalInsuredValue = new Money();
                ((RateRequestPackageSummary)request.Items[0]).TotalInsuredValue.Amount = 100;
                ((RateRequestPackageSummary)request.Items[0]).TotalInsuredValue.Currency = "USD";
                //
                ((RateRequestPackageSummary)request.Items[0]).PieceCount = "2";
                //
                // Types of special services (COD, DRY ICE, HOLD_AT_LOCATION, RESIDENTIAL DELIVERY...)
                ((RateRequestPackageSummary)request.Items[0]).SpecialServicesRequested = new PackageSpecialServicesRequested();
                ((RateRequestPackageSummary)request.Items[0]).SpecialServicesRequested.CodCollectionAmount = new Money();
                ((RateRequestPackageSummary)request.Items[0]).SpecialServicesRequested.CodCollectionAmount.Amount = 100; 
                ((RateRequestPackageSummary)request.Items[0]).SpecialServicesRequested.CodCollectionAmount.Currency = "USD";
            }
            else
            {
                // ------------------------------------------
                // Passing single piece shipment rate request
                // ------------------------------------------
                request.Items = new RequestedPackage[1] { new RequestedPackage() }; // currently only one occurence of RequetedPackage is supported
                ((RequestedPackage)request.Items[0]).SequenceNumber = 1; // package sequence number 


                //
                ((RequestedPackage)request.Items[0]).Weight = new Weight(); // package weight
                ((RequestedPackage)request.Items[0]).Weight.Units = WeightUnits.LB;
                ((RequestedPackage)request.Items[0]).Weight.Value = 15.0M;
                //
                ((RequestedPackage)request.Items[0]).Dimensions = new Dimensions(); // package dimensions
                ((RequestedPackage)request.Items[0]).Dimensions.Length = "1";
                ((RequestedPackage)request.Items[0]).Dimensions.Width = "1";
                ((RequestedPackage)request.Items[0]).Dimensions.Height = "1";
                ((RequestedPackage)request.Items[0]).Dimensions.Units = LinearUnits.IN;
                //
                ((RequestedPackage)request.Items[0]).InsuredValue = new Money(); // insured value
                ((RequestedPackage)request.Items[0]).InsuredValue.Amount = 100;
                ((RequestedPackage)request.Items[0]).InsuredValue.Currency = "USD";
                //
                // Types of special services (COD, DRY_ICE, HOLD_AT_LOCATION, RESIDENTIAL DELIVERY...)
                ((RequestedPackage)request.Items[0]).SpecialServicesRequested = new PackageSpecialServicesRequested();
                //
                ((RequestedPackage)request.Items[0]).SpecialServicesRequested.CodCollectionAmount = new Money();
                ((RequestedPackage)request.Items[0]).SpecialServicesRequested.CodCollectionAmount.Amount = 100;
                ((RequestedPackage)request.Items[0]).SpecialServicesRequested.CodCollectionAmount.Currency = "USD";                
            }
            //
            RateService rateService = new RateService(); // Initialize the service
            try
            {
                // This is the call to the web service passing in a RateRequest and returning a RateReply
                RateReply reply = rateService.getRate(request); // Service call
                
                if (reply.HighestSeverity == NotificationSeverityType.SUCCESS) // check if the call was successful
                {
                    int p = 1;
                    foreach (RatedShipmentDetail shipmentDetail in reply.RatedShipmentDetails)
                    {
                         // This is weight, and charge per package
                        Console.WriteLine("Package {0}", p++);
                        Console.WriteLine("");
                        foreach (RatedPackageDetail ratedPackage in shipmentDetail.RatedPackages)
                         {
                                Console.WriteLine("Billing weight {0} {1}", ratedPackage.PackageRateDetail.BillingWeight.Value, ratedPackage.PackageRateDetail.BillingWeight.Units);
                                Console.WriteLine("");
                                Console.WriteLine("   Base charge {0} {1}", ratedPackage.PackageRateDetail.BaseCharge.Amount, ratedPackage.PackageRateDetail.BaseCharge.Currency);
                                    foreach (Surcharge surcharge in ratedPackage.PackageRateDetail.Surcharges)
                                      Console.WriteLine("{0} surcharge {1} {2}", surcharge.SurchargeType.ToString(), surcharge.Amount.Amount, surcharge.Amount.Currency);
                                                
                                Console.WriteLine("    Net charge {0} {1}", ratedPackage.PackageRateDetail.NetCharge.Amount, ratedPackage.PackageRateDetail.NetCharge.Currency);
                        }
                        if (null != shipmentDetail.ShipmentRateDetail.TotalBillingWeight) // Total weight of all packages
                            Console.WriteLine("Total billing weight {0} {1}", shipmentDetail.ShipmentRateDetail.TotalBillingWeight.Value, shipmentDetail.ShipmentRateDetail.TotalBillingWeight.Units);
                        if (null != shipmentDetail.ShipmentRateDetail.TotalSurcharges) // Total Surcharges for all packages
                            Console.WriteLine("    Total surcharges {0} {1}", shipmentDetail.ShipmentRateDetail.TotalSurcharges.Amount, shipmentDetail.ShipmentRateDetail.TotalSurcharges.Currency);
                        if (null != shipmentDetail.ShipmentRateDetail.TotalNetCharge) // TotalNetCharge is the Rate plus all surcharges for all packages
                            Console.WriteLine("    Total net charge {0} {1}", shipmentDetail.ShipmentRateDetail.TotalNetCharge.Amount, shipmentDetail.ShipmentRateDetail.TotalNetCharge.Currency);
                        
                    }
                    Console.WriteLine("");                                       
                }
                else
                {
                    Console.WriteLine(reply.Notifications[0].Message);
                }
            }
            catch (SoapException e)
            {
                Console.WriteLine(e.Detail.InnerText);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("Press any key to quit !");
            Console.ReadKey();
        }
    }
}
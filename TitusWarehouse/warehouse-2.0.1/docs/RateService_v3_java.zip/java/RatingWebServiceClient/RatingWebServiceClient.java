import java.math.BigDecimal;
import java.util.Date;
import org.apache.axis.types.NonNegativeInteger;
import org.apache.axis.types.PositiveInteger;
import com.fedex.rate.stub.*;

/** 
 * Sample code to call Rate Web Service with Axis 
 * <p>
 * com.fedex.rate.stub is generated via WSDL2Java, like this:<br>
 * <pre>
 * java org.apache.axis.wsdl.WSDL2Java -w -p com.fedex.rate.stub http://www.fedex.com/...../RateService?wsdl
 * </pre>
 */
public class RatingWebServiceClient {  
	//
	public static void main(String[] args) {   
		// Build a RateRequest request object
	    RateRequest request = new RateRequest();
	    request.setClientDetail(createClientDetail());
        request.setWebAuthenticationDetail(createWebAuthenticationDetail());
        
	    //
	    TransactionDetail transactionDetail = new TransactionDetail();
	    transactionDetail.setCustomerTransactionId("java sample - Rate Request"); // The client will get the same value back in the response
	    request.setTransactionDetail(transactionDetail);

        //
        VersionId versionId = new VersionId("crs", 3, 0, 0);
        request.setVersion(versionId);
	    //
	    Address origAddress = new Address(); // Origin information
	    String[] tempAddress = new String[1];
	    tempAddress[0] = "Address Line 1";
	    origAddress.setStreetLines(tempAddress);
	    origAddress.setCity("City Name");
	    origAddress.setStateOrProvinceCode("TN");
	    origAddress.setPostalCode("38115");
	    origAddress.setCountryCode("US");
	    request.setOrigin(origAddress);
	    //
	    Address destAddress = new Address(); // Destination information
	    tempAddress[0] = "Address Line 1";
	    destAddress.setStreetLines(tempAddress);
	    destAddress.setCity("City Name");
	    destAddress.setStateOrProvinceCode("QC");
	    destAddress.setPostalCode("H1E1A1");
	    destAddress.setCountryCode("CA");
	    request.setDestination(destAddress);
	    //
	    Payment payment = new Payment(); // payment information
	    payment.setPaymentType(PaymentType.SENDER); // Payment options are RECIPIENT, SENDER, THIRD_PARTY
	    request.setPayment(payment);
	    //
	    request.setDropoffType(DropoffType.REGULAR_PICKUP); // Dropoff Types are BUSINESS_SERVICE_CENTER, DROP_BOX, REGULAR_PICKUP, REQUEST_COURIER, STATION
	    request.setServiceType(ServiceType.INTERNATIONAL_PRIORITY); // Service Types are FIRST_OVERNIGHT, PRIORITY_OVERNIGHT, ...
	    request.setPackagingType(PackagingType.YOUR_PACKAGING); // Packaging Types are YOUR_PACKAGING, FEDEX_ENVELOPE, FEDEX_BOX, ...
	    //
	    request.setShipDate(new Date());
        //
        // The RateRequest.Items is a choice of one of the following:
        //
        // Array of RateRequestPackageSummary - Details of multi piece shipment rate request - Use this to rate a total piece total weight shipment.
        // Array of RateRequestPackageDetail - Details of simgle piece shipment rate request - Currently only 1 occurance is supported.
        //
        // Not passing one of these choices will result in "Schema Validation Failure", as one of these objects is required.
        //
	    boolean bPassRateRequestPackageSummary = true;
	    //
	    if(bPassRateRequestPackageSummary)
	    {
		    RateRequestPackageSummary packageSummary = new RateRequestPackageSummary();
		    packageSummary.setTotalWeight(new Weight(WeightUnits.LB, new BigDecimal(20.0)));
		    //
		    packageSummary.setTotalInsuredValue(new Money("USD", new BigDecimal("100.00")));
		    //
		    packageSummary.setPieceCount(new PositiveInteger("2",10));
		    //
		    PackageSpecialServicesRequested pssr = new PackageSpecialServicesRequested();
		    packageSummary.setSpecialServicesRequested(pssr);
		    request.setRateRequestPackageSummary(packageSummary);
	    }
	    else
	    {
		    RequestedPackage rp = new RequestedPackage();
		    rp.setWeight(new Weight(WeightUnits.LB, new BigDecimal(15.0)));
		    //
		    rp.setInsuredValue(new Money("USD", new BigDecimal("100.00")));
		    //
		    rp.setDimensions(new Dimensions(new NonNegativeInteger("1"), new NonNegativeInteger("1"), new NonNegativeInteger("1"), LinearUnits.IN));
		    PackageSpecialServicesRequested pssr = new PackageSpecialServicesRequested();
		    rp.setSpecialServicesRequested(pssr);
		    request.setPackages(new RequestedPackage[] {rp});
	    }
	    //
		try {
			// Initialize the service
			RateServiceLocator service;
			RatePortType port;
			//
			service = new RateServiceLocator();
			updateEndPoint(service);
			port = service.getRateServicePort();
			// This is the call to the web service passing in a RateRequest and returning a RateReply
			RateReply reply = port.getRate(request); // Service call
			//
			if (reply.getHighestSeverity().toString().equals(NotificationSeverityType._SUCCESS)) // check if the call was successful
			{
				// This is weight, and charge per package
				RatedShipmentDetail rsd[] = reply.getRatedShipmentDetails();
				for (int i = 0; i < rsd.length; i++) 
				{
					RatedPackageDetail[] rpd = rsd[i].getRatedPackages();
					//
					for(int j = 0; j < rpd.length; j++)
					{
						System.out.println("Package: " + i+1);
						System.out.println("Billing weight: " + rpd[j].getPackageRateDetail().getBillingWeight().getValue() 
									+ " " + rpd[j].getPackageRateDetail().getBillingWeight().getUnits().toString());
						System.out.println("Base charge: " + rpd[j].getPackageRateDetail().getBaseCharge().getAmount() 
									+ " " + rpd[j].getPackageRateDetail().getBaseCharge().getCurrency());
						Surcharge sc[] = rpd[j].getPackageRateDetail().getSurcharges();
						for(int k = 0; k < sc.length; k++)
						{
							System.out.println(sc[k].getSurchargeType().toString() + " surcharge "
									+ sc[k].getAmount().getAmount() + " " + sc[k].getAmount().getCurrency());
						}
						System.out.println("Net charge: " + rpd[j].getPackageRateDetail().getNetCharge().getAmount() + 
								" " + rpd[j].getPackageRateDetail().getNetCharge().getCurrency());
						//
						if (null != rsd[i].getShipmentRateDetail().getTotalBillingWeight())
							System.out.println("\nTotal billing weight: " + rsd[i].getShipmentRateDetail().getTotalBillingWeight().getValue() + " "
									+ rsd[i].getShipmentRateDetail().getTotalBillingWeight().getUnits().toString());
						if (null != rsd[i].getShipmentRateDetail().getTotalSurcharges())
							System.out.println("Total surcharge: " + rsd[i].getShipmentRateDetail().getTotalSurcharges().getAmount() + " "
									+ rsd[i].getShipmentRateDetail().getTotalSurcharges().getCurrency());
						if (null != rsd[i].getShipmentRateDetail().getTotalNetCharge())
							System.out.println("Total net charge: " + rsd[i].getShipmentRateDetail().getTotalNetCharge().getAmount() + " "
									+ rsd[i].getShipmentRateDetail().getTotalNetCharge().getCurrency());
					}
				}
				//
			}	
			else {
				printNotifications(reply.getNotifications());
			}
		} catch (Exception e) {
		    e.printStackTrace();
		} 
	}
	
	private static ClientDetail createClientDetail() {
        ClientDetail clientDetail = new ClientDetail();
        String accountNumber = System.getProperty("accountNumber");
        String meterNumber = System.getProperty("meterNumber");
        
        //
        // See if the accountNumber and meterNumber properties are set,
        // if set use those values, otherwise default them to "XXX"
        //
        if (accountNumber == null) {
        	accountNumber = "XXX"; // Replace "XXX" with clients account number
        }
        if (meterNumber == null) {
        	meterNumber = "XXX"; // Replace "XXX" with clients meter number
        }
        clientDetail.setAccountNumber(accountNumber);
        clientDetail.setMeterNumber(meterNumber);
        return clientDetail;
	}
	
	private static WebAuthenticationDetail createWebAuthenticationDetail() {
        WebAuthenticationCredential wac = new WebAuthenticationCredential();
        String key = System.getProperty("key");
        String password = System.getProperty("password");
        
        //
        // See if the key and password properties are set,
        // if set use those values, otherwise default them to "XXX"
        //
        if (key == null) {
        	key = "XXX"; // Replace "XXX" with clients key
        }
        if (password == null) {
        	password = "XXX"; // Replace "XXX" with clients password
        }
        wac.setKey(key);
        wac.setPassword(password);
		return new WebAuthenticationDetail(wac);
	}
	
	private static void printNotifications(Notification[] notifications) {
		System.out.println("Notifications:");
		if (notifications == null || notifications.length == 0) {
			System.out.println("  No notifications returned");
		}
		for (int i=0; i < notifications.length; i++){
			Notification n = notifications[i];
			System.out.print("  Notification no. " + i + ": ");
			if (n == null) {
				System.out.println("null");
				continue;
			} else {
				System.out.println("");
			}
			NotificationSeverityType nst = n.getSeverity();

			System.out.println("    Severity: " + (nst == null ? "null" : nst.getValue()));
			System.out.println("    Code: " + n.getCode());
			System.out.println("    Message: " + n.getMessage());
			System.out.println("    Source: " + n.getSource());
		}
	}
	
	private static void updateEndPoint(RateServiceLocator serviceLocator) {
		String endPoint = System.getProperty("endPoint");
		if (endPoint != null) {
			serviceLocator.setRateServicePortEndpointAddress(endPoint);
		}
	}

}

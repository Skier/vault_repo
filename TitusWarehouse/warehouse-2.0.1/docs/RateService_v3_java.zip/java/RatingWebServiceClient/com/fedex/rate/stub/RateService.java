/**
 * RateService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.fedex.rate.stub;

public interface RateService extends javax.xml.rpc.Service {
    public java.lang.String getRateServicePortAddress();

    public com.fedex.rate.stub.RatePortType getRateServicePort() throws javax.xml.rpc.ServiceException;

    public com.fedex.rate.stub.RatePortType getRateServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

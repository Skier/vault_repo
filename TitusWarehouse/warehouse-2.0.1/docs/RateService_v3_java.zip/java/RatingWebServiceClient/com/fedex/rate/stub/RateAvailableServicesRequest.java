/**
 * RateAvailableServicesRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.fedex.rate.stub;


/**
 * The descriptive data to request the FedEx service(s) available
 * and courtesy rate quote(s) rates for the specified service, packaging,
 * and origin/destination criteria. If a FedEx transportation service
 * is specified, a courtesy rate quote for that service is returned.
 * If no FedEx transportation service is specified, courtesy rate quote
 * for all available services for the origin/destination criteria are
 * returned.
 */
public class RateAvailableServicesRequest  implements java.io.Serializable {
    /* The descriptive data to be used in authentication of the sender's
     * identity (and right to use FedEx web services). */
    private com.fedex.rate.stub.WebAuthenticationDetail webAuthenticationDetail;

    /* The descriptive data identifying the client submitting the
     * transaction. */
    private com.fedex.rate.stub.ClientDetail clientDetail;

    /* The descriptive data for this customer transaction. The TransactionDetail
     * from the request is echoed back to the caller in the corresponding
     * reply. */
    private com.fedex.rate.stub.TransactionDetail transactionDetail;

    /* Identifies the version/level of a service operation expected
     * by a caller (in each request) and performed by the callee (in each
     * reply). */
    private com.fedex.rate.stub.VersionId version;

    /* The descriptive data for the physical location from which the
     * shipment originates. */
    private com.fedex.rate.stub.Address origin;

    /* The descriptive data for the physical location to which the
     * shipment is destined. */
    private com.fedex.rate.stub.Address destination;

    /* Identifies the preferred currency of the requestor using the
     * standard 3-character ISO currency codes. */
    private java.lang.String currencyType;

    /* Descriptive data providing details about how to calculate variable
     * handling charges at the package level. */
    private com.fedex.rate.stub.VariableHandlingChargeDetail variableHandlingChargeDetail;

    /* Identifies the method by which the package is to be tendered
     * to FedEx. This element does not dispatch a courier for package pickup. */
    private com.fedex.rate.stub.DropoffType dropoffType;

    /* Identifies the FedEx operating company (transportation) responsible
     * for handling the shipment. Currently the supported carriers for this
     * web service request are FDXE (FedEx Express) and FDXG (FedEx Ground).
     * If the CarrierCode is left blank, Express and Ground (if applicable/available)
     * are returned in the reply. */
    private com.fedex.rate.stub.CarrierCodeType carrierCode;

    /* Identifies the FedEx service to use in shipping the package.
     * See ServiceType for valid values. If not specified, the web service
     * returns rates for all the services available for the origin/destination
     * pair. */
    private com.fedex.rate.stub.ServiceType serviceType;

    /* Identifies the packaging used by the requestor for the package. */
    private com.fedex.rate.stub.PackagingType packagingType;

    /* Identifies the date of the shipment. The date should not be
     * a past date or a date more than 10 days in the future. The date component
     * must be in the format: YYYY-MM-DD (e.g. 2006-06-26). */
    private java.util.Date shipDate;

    /* Descriptive data regarding special services requested by the
     * shipper for this shipment. If the shipper is requesting a special
     * service which requires additional data (e.g. COD), the special service
     * type must be present in the specialServiceTypes collection, and the
     * supporting detail must be provided in the appropriate sub-object.
     * For example, to request COD, "COD" must be included in the SpecialServiceTypes
     * collection and the CodDetail object must contain the required data. */
    private com.fedex.rate.stub.ShipmentSpecialServicesRequested specialServicesRequested;

    /* Indicates the type of rates to be returned. */
    private com.fedex.rate.stub.RateRequestType[] rateRequestTypes;

    /* Describes summary data about the shipment. */
    private com.fedex.rate.stub.RateRequestPackageSummary rateRequestPackageSummary;

    public RateAvailableServicesRequest() {
    }

    public RateAvailableServicesRequest(
           com.fedex.rate.stub.WebAuthenticationDetail webAuthenticationDetail,
           com.fedex.rate.stub.ClientDetail clientDetail,
           com.fedex.rate.stub.TransactionDetail transactionDetail,
           com.fedex.rate.stub.VersionId version,
           com.fedex.rate.stub.Address origin,
           com.fedex.rate.stub.Address destination,
           java.lang.String currencyType,
           com.fedex.rate.stub.VariableHandlingChargeDetail variableHandlingChargeDetail,
           com.fedex.rate.stub.DropoffType dropoffType,
           com.fedex.rate.stub.CarrierCodeType carrierCode,
           com.fedex.rate.stub.ServiceType serviceType,
           com.fedex.rate.stub.PackagingType packagingType,
           java.util.Date shipDate,
           com.fedex.rate.stub.ShipmentSpecialServicesRequested specialServicesRequested,
           com.fedex.rate.stub.RateRequestType[] rateRequestTypes,
           com.fedex.rate.stub.RateRequestPackageSummary rateRequestPackageSummary) {
           this.webAuthenticationDetail = webAuthenticationDetail;
           this.clientDetail = clientDetail;
           this.transactionDetail = transactionDetail;
           this.version = version;
           this.origin = origin;
           this.destination = destination;
           this.currencyType = currencyType;
           this.variableHandlingChargeDetail = variableHandlingChargeDetail;
           this.dropoffType = dropoffType;
           this.carrierCode = carrierCode;
           this.serviceType = serviceType;
           this.packagingType = packagingType;
           this.shipDate = shipDate;
           this.specialServicesRequested = specialServicesRequested;
           this.rateRequestTypes = rateRequestTypes;
           this.rateRequestPackageSummary = rateRequestPackageSummary;
    }


    /**
     * Gets the webAuthenticationDetail value for this RateAvailableServicesRequest.
     * 
     * @return webAuthenticationDetail   * The descriptive data to be used in authentication of the sender's
     * identity (and right to use FedEx web services).
     */
    public com.fedex.rate.stub.WebAuthenticationDetail getWebAuthenticationDetail() {
        return webAuthenticationDetail;
    }


    /**
     * Sets the webAuthenticationDetail value for this RateAvailableServicesRequest.
     * 
     * @param webAuthenticationDetail   * The descriptive data to be used in authentication of the sender's
     * identity (and right to use FedEx web services).
     */
    public void setWebAuthenticationDetail(com.fedex.rate.stub.WebAuthenticationDetail webAuthenticationDetail) {
        this.webAuthenticationDetail = webAuthenticationDetail;
    }


    /**
     * Gets the clientDetail value for this RateAvailableServicesRequest.
     * 
     * @return clientDetail   * The descriptive data identifying the client submitting the
     * transaction.
     */
    public com.fedex.rate.stub.ClientDetail getClientDetail() {
        return clientDetail;
    }


    /**
     * Sets the clientDetail value for this RateAvailableServicesRequest.
     * 
     * @param clientDetail   * The descriptive data identifying the client submitting the
     * transaction.
     */
    public void setClientDetail(com.fedex.rate.stub.ClientDetail clientDetail) {
        this.clientDetail = clientDetail;
    }


    /**
     * Gets the transactionDetail value for this RateAvailableServicesRequest.
     * 
     * @return transactionDetail   * The descriptive data for this customer transaction. The TransactionDetail
     * from the request is echoed back to the caller in the corresponding
     * reply.
     */
    public com.fedex.rate.stub.TransactionDetail getTransactionDetail() {
        return transactionDetail;
    }


    /**
     * Sets the transactionDetail value for this RateAvailableServicesRequest.
     * 
     * @param transactionDetail   * The descriptive data for this customer transaction. The TransactionDetail
     * from the request is echoed back to the caller in the corresponding
     * reply.
     */
    public void setTransactionDetail(com.fedex.rate.stub.TransactionDetail transactionDetail) {
        this.transactionDetail = transactionDetail;
    }


    /**
     * Gets the version value for this RateAvailableServicesRequest.
     * 
     * @return version   * Identifies the version/level of a service operation expected
     * by a caller (in each request) and performed by the callee (in each
     * reply).
     */
    public com.fedex.rate.stub.VersionId getVersion() {
        return version;
    }


    /**
     * Sets the version value for this RateAvailableServicesRequest.
     * 
     * @param version   * Identifies the version/level of a service operation expected
     * by a caller (in each request) and performed by the callee (in each
     * reply).
     */
    public void setVersion(com.fedex.rate.stub.VersionId version) {
        this.version = version;
    }


    /**
     * Gets the origin value for this RateAvailableServicesRequest.
     * 
     * @return origin   * The descriptive data for the physical location from which the
     * shipment originates.
     */
    public com.fedex.rate.stub.Address getOrigin() {
        return origin;
    }


    /**
     * Sets the origin value for this RateAvailableServicesRequest.
     * 
     * @param origin   * The descriptive data for the physical location from which the
     * shipment originates.
     */
    public void setOrigin(com.fedex.rate.stub.Address origin) {
        this.origin = origin;
    }


    /**
     * Gets the destination value for this RateAvailableServicesRequest.
     * 
     * @return destination   * The descriptive data for the physical location to which the
     * shipment is destined.
     */
    public com.fedex.rate.stub.Address getDestination() {
        return destination;
    }


    /**
     * Sets the destination value for this RateAvailableServicesRequest.
     * 
     * @param destination   * The descriptive data for the physical location to which the
     * shipment is destined.
     */
    public void setDestination(com.fedex.rate.stub.Address destination) {
        this.destination = destination;
    }


    /**
     * Gets the currencyType value for this RateAvailableServicesRequest.
     * 
     * @return currencyType   * Identifies the preferred currency of the requestor using the
     * standard 3-character ISO currency codes.
     */
    public java.lang.String getCurrencyType() {
        return currencyType;
    }


    /**
     * Sets the currencyType value for this RateAvailableServicesRequest.
     * 
     * @param currencyType   * Identifies the preferred currency of the requestor using the
     * standard 3-character ISO currency codes.
     */
    public void setCurrencyType(java.lang.String currencyType) {
        this.currencyType = currencyType;
    }


    /**
     * Gets the variableHandlingChargeDetail value for this RateAvailableServicesRequest.
     * 
     * @return variableHandlingChargeDetail   * Descriptive data providing details about how to calculate variable
     * handling charges at the package level.
     */
    public com.fedex.rate.stub.VariableHandlingChargeDetail getVariableHandlingChargeDetail() {
        return variableHandlingChargeDetail;
    }


    /**
     * Sets the variableHandlingChargeDetail value for this RateAvailableServicesRequest.
     * 
     * @param variableHandlingChargeDetail   * Descriptive data providing details about how to calculate variable
     * handling charges at the package level.
     */
    public void setVariableHandlingChargeDetail(com.fedex.rate.stub.VariableHandlingChargeDetail variableHandlingChargeDetail) {
        this.variableHandlingChargeDetail = variableHandlingChargeDetail;
    }


    /**
     * Gets the dropoffType value for this RateAvailableServicesRequest.
     * 
     * @return dropoffType   * Identifies the method by which the package is to be tendered
     * to FedEx. This element does not dispatch a courier for package pickup.
     */
    public com.fedex.rate.stub.DropoffType getDropoffType() {
        return dropoffType;
    }


    /**
     * Sets the dropoffType value for this RateAvailableServicesRequest.
     * 
     * @param dropoffType   * Identifies the method by which the package is to be tendered
     * to FedEx. This element does not dispatch a courier for package pickup.
     */
    public void setDropoffType(com.fedex.rate.stub.DropoffType dropoffType) {
        this.dropoffType = dropoffType;
    }


    /**
     * Gets the carrierCode value for this RateAvailableServicesRequest.
     * 
     * @return carrierCode   * Identifies the FedEx operating company (transportation) responsible
     * for handling the shipment. Currently the supported carriers for this
     * web service request are FDXE (FedEx Express) and FDXG (FedEx Ground).
     * If the CarrierCode is left blank, Express and Ground (if applicable/available)
     * are returned in the reply.
     */
    public com.fedex.rate.stub.CarrierCodeType getCarrierCode() {
        return carrierCode;
    }


    /**
     * Sets the carrierCode value for this RateAvailableServicesRequest.
     * 
     * @param carrierCode   * Identifies the FedEx operating company (transportation) responsible
     * for handling the shipment. Currently the supported carriers for this
     * web service request are FDXE (FedEx Express) and FDXG (FedEx Ground).
     * If the CarrierCode is left blank, Express and Ground (if applicable/available)
     * are returned in the reply.
     */
    public void setCarrierCode(com.fedex.rate.stub.CarrierCodeType carrierCode) {
        this.carrierCode = carrierCode;
    }


    /**
     * Gets the serviceType value for this RateAvailableServicesRequest.
     * 
     * @return serviceType   * Identifies the FedEx service to use in shipping the package.
     * See ServiceType for valid values. If not specified, the web service
     * returns rates for all the services available for the origin/destination
     * pair.
     */
    public com.fedex.rate.stub.ServiceType getServiceType() {
        return serviceType;
    }


    /**
     * Sets the serviceType value for this RateAvailableServicesRequest.
     * 
     * @param serviceType   * Identifies the FedEx service to use in shipping the package.
     * See ServiceType for valid values. If not specified, the web service
     * returns rates for all the services available for the origin/destination
     * pair.
     */
    public void setServiceType(com.fedex.rate.stub.ServiceType serviceType) {
        this.serviceType = serviceType;
    }


    /**
     * Gets the packagingType value for this RateAvailableServicesRequest.
     * 
     * @return packagingType   * Identifies the packaging used by the requestor for the package.
     */
    public com.fedex.rate.stub.PackagingType getPackagingType() {
        return packagingType;
    }


    /**
     * Sets the packagingType value for this RateAvailableServicesRequest.
     * 
     * @param packagingType   * Identifies the packaging used by the requestor for the package.
     */
    public void setPackagingType(com.fedex.rate.stub.PackagingType packagingType) {
        this.packagingType = packagingType;
    }


    /**
     * Gets the shipDate value for this RateAvailableServicesRequest.
     * 
     * @return shipDate   * Identifies the date of the shipment. The date should not be
     * a past date or a date more than 10 days in the future. The date component
     * must be in the format: YYYY-MM-DD (e.g. 2006-06-26).
     */
    public java.util.Date getShipDate() {
        return shipDate;
    }


    /**
     * Sets the shipDate value for this RateAvailableServicesRequest.
     * 
     * @param shipDate   * Identifies the date of the shipment. The date should not be
     * a past date or a date more than 10 days in the future. The date component
     * must be in the format: YYYY-MM-DD (e.g. 2006-06-26).
     */
    public void setShipDate(java.util.Date shipDate) {
        this.shipDate = shipDate;
    }


    /**
     * Gets the specialServicesRequested value for this RateAvailableServicesRequest.
     * 
     * @return specialServicesRequested   * Descriptive data regarding special services requested by the
     * shipper for this shipment. If the shipper is requesting a special
     * service which requires additional data (e.g. COD), the special service
     * type must be present in the specialServiceTypes collection, and the
     * supporting detail must be provided in the appropriate sub-object.
     * For example, to request COD, "COD" must be included in the SpecialServiceTypes
     * collection and the CodDetail object must contain the required data.
     */
    public com.fedex.rate.stub.ShipmentSpecialServicesRequested getSpecialServicesRequested() {
        return specialServicesRequested;
    }


    /**
     * Sets the specialServicesRequested value for this RateAvailableServicesRequest.
     * 
     * @param specialServicesRequested   * Descriptive data regarding special services requested by the
     * shipper for this shipment. If the shipper is requesting a special
     * service which requires additional data (e.g. COD), the special service
     * type must be present in the specialServiceTypes collection, and the
     * supporting detail must be provided in the appropriate sub-object.
     * For example, to request COD, "COD" must be included in the SpecialServiceTypes
     * collection and the CodDetail object must contain the required data.
     */
    public void setSpecialServicesRequested(com.fedex.rate.stub.ShipmentSpecialServicesRequested specialServicesRequested) {
        this.specialServicesRequested = specialServicesRequested;
    }


    /**
     * Gets the rateRequestTypes value for this RateAvailableServicesRequest.
     * 
     * @return rateRequestTypes   * Indicates the type of rates to be returned.
     */
    public com.fedex.rate.stub.RateRequestType[] getRateRequestTypes() {
        return rateRequestTypes;
    }


    /**
     * Sets the rateRequestTypes value for this RateAvailableServicesRequest.
     * 
     * @param rateRequestTypes   * Indicates the type of rates to be returned.
     */
    public void setRateRequestTypes(com.fedex.rate.stub.RateRequestType[] rateRequestTypes) {
        this.rateRequestTypes = rateRequestTypes;
    }

    public com.fedex.rate.stub.RateRequestType getRateRequestTypes(int i) {
        return this.rateRequestTypes[i];
    }

    public void setRateRequestTypes(int i, com.fedex.rate.stub.RateRequestType _value) {
        this.rateRequestTypes[i] = _value;
    }


    /**
     * Gets the rateRequestPackageSummary value for this RateAvailableServicesRequest.
     * 
     * @return rateRequestPackageSummary   * Describes summary data about the shipment.
     */
    public com.fedex.rate.stub.RateRequestPackageSummary getRateRequestPackageSummary() {
        return rateRequestPackageSummary;
    }


    /**
     * Sets the rateRequestPackageSummary value for this RateAvailableServicesRequest.
     * 
     * @param rateRequestPackageSummary   * Describes summary data about the shipment.
     */
    public void setRateRequestPackageSummary(com.fedex.rate.stub.RateRequestPackageSummary rateRequestPackageSummary) {
        this.rateRequestPackageSummary = rateRequestPackageSummary;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RateAvailableServicesRequest)) return false;
        RateAvailableServicesRequest other = (RateAvailableServicesRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.webAuthenticationDetail==null && other.getWebAuthenticationDetail()==null) || 
             (this.webAuthenticationDetail!=null &&
              this.webAuthenticationDetail.equals(other.getWebAuthenticationDetail()))) &&
            ((this.clientDetail==null && other.getClientDetail()==null) || 
             (this.clientDetail!=null &&
              this.clientDetail.equals(other.getClientDetail()))) &&
            ((this.transactionDetail==null && other.getTransactionDetail()==null) || 
             (this.transactionDetail!=null &&
              this.transactionDetail.equals(other.getTransactionDetail()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion()))) &&
            ((this.origin==null && other.getOrigin()==null) || 
             (this.origin!=null &&
              this.origin.equals(other.getOrigin()))) &&
            ((this.destination==null && other.getDestination()==null) || 
             (this.destination!=null &&
              this.destination.equals(other.getDestination()))) &&
            ((this.currencyType==null && other.getCurrencyType()==null) || 
             (this.currencyType!=null &&
              this.currencyType.equals(other.getCurrencyType()))) &&
            ((this.variableHandlingChargeDetail==null && other.getVariableHandlingChargeDetail()==null) || 
             (this.variableHandlingChargeDetail!=null &&
              this.variableHandlingChargeDetail.equals(other.getVariableHandlingChargeDetail()))) &&
            ((this.dropoffType==null && other.getDropoffType()==null) || 
             (this.dropoffType!=null &&
              this.dropoffType.equals(other.getDropoffType()))) &&
            ((this.carrierCode==null && other.getCarrierCode()==null) || 
             (this.carrierCode!=null &&
              this.carrierCode.equals(other.getCarrierCode()))) &&
            ((this.serviceType==null && other.getServiceType()==null) || 
             (this.serviceType!=null &&
              this.serviceType.equals(other.getServiceType()))) &&
            ((this.packagingType==null && other.getPackagingType()==null) || 
             (this.packagingType!=null &&
              this.packagingType.equals(other.getPackagingType()))) &&
            ((this.shipDate==null && other.getShipDate()==null) || 
             (this.shipDate!=null &&
              this.shipDate.equals(other.getShipDate()))) &&
            ((this.specialServicesRequested==null && other.getSpecialServicesRequested()==null) || 
             (this.specialServicesRequested!=null &&
              this.specialServicesRequested.equals(other.getSpecialServicesRequested()))) &&
            ((this.rateRequestTypes==null && other.getRateRequestTypes()==null) || 
             (this.rateRequestTypes!=null &&
              java.util.Arrays.equals(this.rateRequestTypes, other.getRateRequestTypes()))) &&
            ((this.rateRequestPackageSummary==null && other.getRateRequestPackageSummary()==null) || 
             (this.rateRequestPackageSummary!=null &&
              this.rateRequestPackageSummary.equals(other.getRateRequestPackageSummary())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWebAuthenticationDetail() != null) {
            _hashCode += getWebAuthenticationDetail().hashCode();
        }
        if (getClientDetail() != null) {
            _hashCode += getClientDetail().hashCode();
        }
        if (getTransactionDetail() != null) {
            _hashCode += getTransactionDetail().hashCode();
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        if (getOrigin() != null) {
            _hashCode += getOrigin().hashCode();
        }
        if (getDestination() != null) {
            _hashCode += getDestination().hashCode();
        }
        if (getCurrencyType() != null) {
            _hashCode += getCurrencyType().hashCode();
        }
        if (getVariableHandlingChargeDetail() != null) {
            _hashCode += getVariableHandlingChargeDetail().hashCode();
        }
        if (getDropoffType() != null) {
            _hashCode += getDropoffType().hashCode();
        }
        if (getCarrierCode() != null) {
            _hashCode += getCarrierCode().hashCode();
        }
        if (getServiceType() != null) {
            _hashCode += getServiceType().hashCode();
        }
        if (getPackagingType() != null) {
            _hashCode += getPackagingType().hashCode();
        }
        if (getShipDate() != null) {
            _hashCode += getShipDate().hashCode();
        }
        if (getSpecialServicesRequested() != null) {
            _hashCode += getSpecialServicesRequested().hashCode();
        }
        if (getRateRequestTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRateRequestTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRateRequestTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRateRequestPackageSummary() != null) {
            _hashCode += getRateRequestPackageSummary().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RateAvailableServicesRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "RateAvailableServicesRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webAuthenticationDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "WebAuthenticationDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "WebAuthenticationDetail"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "ClientDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "ClientDetail"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "TransactionDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "TransactionDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "Version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "VersionId"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("origin");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "Origin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "Address"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("destination");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "Destination"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "Address"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "CurrencyType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("variableHandlingChargeDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "VariableHandlingChargeDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "VariableHandlingChargeDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dropoffType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "DropoffType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "DropoffType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("carrierCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "CarrierCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "CarrierCodeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "ServiceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "ServiceType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("packagingType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "PackagingType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "PackagingType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shipDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "ShipDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("specialServicesRequested");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "SpecialServicesRequested"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "ShipmentSpecialServicesRequested"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rateRequestTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "RateRequestTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "RateRequestType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rateRequestPackageSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "RateRequestPackageSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://fedex.com/ws/rate/v3", "RateRequestPackageSummary"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

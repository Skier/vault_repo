#!/bin/sh
autoconf

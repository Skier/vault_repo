var di;
function webORB(a,t,k)
{
this.a=a;
this.t=t;
this.k=k;
webORB.registerTypeFactory("RecordSet",createRecordSet);
}
webORB.bind=function(targetName,a,t,k)
{
var b=new webORB(a,t,k);
var ap;
try
{
ap=b.dd(targetName);
}
catch(e)
{
alert("error binding to object - "+e.description);
}
return webORB.createProxy(ap,targetName,b);
}
webORB.asyncBind=function(targetName,a,t,k,async)
{
var b=new webORB(a,t,k);
var ap;
var h3=async.bz;
async.bz=new Function("arguments.callee.h3.call( this.callbackOwner, webORB.createProxy( arguments[ 0 ], arguments.callee.targetName, arguments.callee.b ) )");
async.bz.b=b;
async.bz.targetName=targetName;
async.bz.h3=h3;
b.dd(targetName,async);
}
webORB.createProxy=function(ap,targetName,b)
{
var ae=new Object();
for(var au=0;au<ap.functions.length;au++)
{
var bq=ap.functions[au].name;
ae[bq]=new Function("return arguments.callee.b.handleInvocation( arguments.callee._name, arguments.callee._targetname, this, arguments )");
ae[bq]._name=bq;
ae[bq]._targetname=targetName;
ae[bq].b=b;
}
ae.b=b;
return ae;
}
webORB.setCredentials=function(t,k,ae)
{
ae.b.setCredentials(t,k);
}
webORB.setCredentialsEncryptionFunction=function(func,ae)
{
ae.b.setCredentialsEncryptionFunction(func);
}
webORB.setActivationMode=function(activationMode,ae)
{
ae.b.setActivationMode(activationMode);
}
webORB.setDebugListener=function(c,ae)
{
ae.b.setDebugListener(c);
}
webORB.factoryMethods=new Object();
webORB.registerTypeFactory=function(className,func)
{
webORB.factoryMethods[className]=func;
}
webORB.prototype=
{
k:undefined,
a:undefined,
t:undefined,
cm:1,
bf:undefined,
c:undefined,
dd:function(targetName,async)
{
var cu="<WOLF version=\"1.0\"><Request id=\"0\"><Headers><InspectService><Boolean>true</Boolean></InspectService></Headers><Target>"+targetName+"</Target><Method>none</Method><Arguments /></Request></WOLF>";
var d=this.y(async);
if(async!=null)
async.setComm(d,this);
var bk=d.send(cu);
if(async!=null)
return;
if(d.responseXML.firstChild!=null)
return this.cn(d.responseXML);
else
return this.ao(d.responseText);
},
ao:function(responseText)
{
if(document.implementation&&document.implementation.createDocument)
{
dc=document.implementation.createDocument("","",null);
Document.prototype._this=this;
Document.prototype.loadXML=function(strXML)
{
var by=new DOMParser();
var be=by.parseFromString(strXML,"text/xml");
while(this.hasChildNodes())
this.removeChild(this.lastChild);
if(typeof(this.importNode)=="function")
{
for(var au=0;au<be.childNodes.length;au++)
this.appendChild(be.importNode(be.childNodes[au],true));
}
else
{
for(var au=0;au<be.childNodes.length;au++)
this.appendChild(be.childNodes[au].cloneNode(true));
};
}
}
else if(window.ActiveXObject)
{
dc=new ActiveXObject("Microsoft.XMLDOM");
dc.async=false;
dc.validateOnParse=false;
}
else
{
alert('Your browser can\'t handle this script');
return;
}
dc.loadXML(responseText);
return this.cn(dc);
},
y:function(g)
{
var bx=null;
try
{
bx=new XMLHttpRequest();
}
catch(e)
{
var ah=new Array(
'MSXML2.XMLHTTP.5.0',
'MSXML2.XMLHTTP.4.0',
'MSXML2.XMLHTTP.3.0',
'MSXML2.XMLHTTP',
'Microsoft.XMLHTTP'
);
var cc=false;
for(var au=0;au<ah.length&&!cc;au++)
{
try
{
bx=new ActiveXObject(ah[au]);
cc=true;
}
catch(e)
{
}
}
}
try
{
bx.open("POST",this.a,g!=null);
}
catch(e)
{
throw e;
}
bx.setRequestHeader("Content-Type","wolf/xml");
bx.onreadystatechange=function()
{
if(g!=null)
g.setLastState(bx.readyState);
};
return bx;
},
cn:function(responseDoc)
{
var z=responseDoc.firstChild.getElementsByTagName("Response")[0];
if(z!=null)
return this.ar(z.firstChild,new Array());
z=responseDoc.firstChild.getElementsByTagName("Fault")[0];
if(z!=null)
throw this.ar(z.firstChild,new Array());
},
ar:function(dataElement,refMap)
{
switch(dataElement.nodeName)
{
case"Object":
var ch=dataElement.getAttribute("referenceID");
var ab=new Object();
refMap[ch]=ab;
var childNodes=dataElement.childNodes;
for(var au=0;au<childNodes.length;au++)
{
var fieldName=childNodes[au].getElementsByTagName("Name")[0].firstChild.nodeValue;
var br=childNodes[au].getElementsByTagName("Value")[0].firstChild;
var fieldValue=this.ar(br,refMap);
ab[fieldName]=fieldValue;
}
var aw=dataElement.getAttribute("objectName");
if(aw!=undefined)
{
var ba=this.bi(aw);
if(ba!=undefined)
return ba.call(null,ab,this);
else
return ab;
}
else
{
return ab;
}
break;
case"Boolean":
return dataElement.firstChild.nodeValue=="true";
break;
case"Number":
var bw=dataElement.firstChild.nodeValue;
var bd;
if(bw.indexOf('.')>-1)
return parseFloat(bw);
else
return parseInt(bw);
break;
case"String":
if(dataElement.firstChild)
return dataElement.firstChild.nodeValue;
else
return"";
break;
case"Undefined":
return undefined;
break;
case"Date":
return new Date(dataElement.firstChild.nodeValue);
break;
case"Array":
var ch=dataElement.getAttribute("referenceID");
var bj=new Array(dataElement.childNodes.length);
refMap[ch]=bj;
for(var au=0;au<dataElement.childNodes.length;au++)
{
var ai=this.ar(dataElement.childNodes[au],refMap);
bj[au]=ai;
}
return bj;
break;
case"Reference":
return refMap[dataElement.firstChild.nodeValue];
break;
case"XML":
break;
default:
alert("unknown data type - "+dataElement.nodeName);
break;
}
},
handleInvocation:function(funcName,targetName,proxyObj,p)
{
var g=this.bl(p);
var av=(g!=null);
if(this.c!=null)
this.c.receivedInvocationRequest(funcName,targetName,av);
var d=this.y(g);
var requestXML=this.bh(funcName,targetName,p,av);
if(this.c!=null)
this.c.createdRequestDocument(requestXML);
if(av)
g.setComm(d,this);
var bk=null;
if(requestXML.xml)
bk=d.send(requestXML.xml);
else
bk=d.send(requestXML);
if(this.c!=null)
this.c.requestSent();
if(av)
return;
if(this.c!=null)
this.c.receivedResponse(d.responseText);
return this.ao(d.responseText);
},
bh:function(funcName,targetName,p,av)
{
var requestXML=this.createDocument();
var at=requestXML.createElement("WOLF");
at.setAttribute("version","1.0");
requestXML.appendChild(at);
var s=requestXML.createElement("Request");
s.setAttribute("id",this.cm++);
at.appendChild(s);
if(this.t!=null&&this.k!=null)
{
var az=requestXML.createElement("Headers");
var x=new Object();
if(this.bf!=undefined)
{
x.t=this.bf.call(null,this.t);
x.k=this.bf.call(null,this.k);
}
else
{
x.t=this.t;
x.k=this.k;
}
var am=requestXML.createElement("Credentials");
am.appendChild(this.u(x,requestXML));
az.appendChild(am);
s.appendChild(az);
}
s.appendChild(this.createElement("Target",targetName,requestXML));
s.appendChild(this.createElement("Method",funcName,requestXML));
var bg=requestXML.createElement("Arguments");
s.appendChild(bg);
var da=0;
if(p!=undefined)
da=av?p.length-1:p.length;
for(var au=0;au<da;au++)
bg.appendChild(this.u(p[au],requestXML));
return requestXML;
},
createDocument:function()
{
var requestXML;
if(document.implementation&&document.implementation.createDocument)
requestXML=document.implementation.createDocument("","",null);
else if(window.ActiveXObject)
requestXML=new ActiveXObject("Microsoft.XMLDOM");
return requestXML;
},
bl:function(p)
{
if(p==undefined||p.length==0||p[p.length-1]==null)
return null;
var cq=p[p.length-1].constructor;
if(typeof(cq)!="function")
return null;
var bp=cq.toString().match(/\s*function (.*)\(/);
if(bp!=null&&bp[1]=="Async")
return g=p[p.length-1];
else
return null;
},
u:function(ab,xmlNode)
{
switch(typeof(ab))
{
case"number":
return this.createElement('Number',ab,xmlNode);
break;
case"string":
return this.createElement("String",ab,xmlNode);
break;
case"boolean":
return this.createElement("Boolean",ab?"true":"false",xmlNode);
break;
case"object":
if(ab==null)
return xmlNode.createElement("Undefined");
else if(ab.constructor!=null)
{
switch(ab.constructor)
{
case Array:
var ai=xmlNode.createElement("Array");
for(var au=0;au<ab.length;au++)
{
var ef=this.u(ab[au],xmlNode);
ai.appendChild(ef);
}
return ai;
break;
case Date:
return this.createElement("Date",ab.getTime(),xmlNode);
break;
case Object:
return this.aj(ab,undefined,xmlNode);
break;
default:
var ct=ab.constructor.toString();
var cp=ct.match(/\s*function (.*)\(/);
if(cp!=null)
return this.aj(ab,cp[1],xmlNode);
break;
}
}
break;
case"function":
break;
case"undefined":
return xmlNode.createElement("Undefined");
break;
}
},
aj:function(ab,aw,xmlNode)
{
var ay=xmlNode.createElement("Object");
if(aw!=undefined)
ay.setAttribute("objectName",aw);
for(var n in ab)
{
if(typeof(ab[n])=="function")
continue;
var aq=xmlNode.createElement("Field");
aq.appendChild(this.createElement("Name",n,xmlNode));
var bc=xmlNode.createElement("Value");
bc.appendChild(this.u(ab[n],xmlNode));
aq.appendChild(bc);
ay.appendChild(aq);
}
return ay;
},
createElement:function(elementName,elementValue,xmlNode)
{
var bo=xmlNode.createElement(elementName);
var cb=xmlNode.createTextNode(elementValue);
bo.appendChild(cb);
return bo;
},
bi:function(objectName)
{
return webORB.factoryMethods[objectName];
},
setCredentialsEncryptionFunction:function(func)
{
this.bf=func;
},
setCredentials:function(t,k)
{
this.t=t;
this.k=k;
},
setActivationMode:function(activationMode)
{
if(this.a.indexOf("?")==-1)
this.a=this.a+"?activate="+activationMode;
else
{
if(this.a.indexOf("activate=")==-1)
{
if(this.a.charAt(this.a.length-1)!='&')
this.a+="&";
this.a+="activate="+activationMode;
}
else
{
var ce=this.a.indexOf("activate=");
var cx="activate=".length;
var co=this.a.substr(ce+cx);
var ak=co.indexOf("&");
if(ak==-1)
this.a=this.a.substr(0,ce)+"activate="+activationMode;
else
this.a=this.a.substr(0,ce)+"activate="+activationMode+this.a.substr(ak);
}
}
},
setDebugListener:function(c)
{
this.c=c;
}
}
function base64(bu)
{
var bn="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
var bv="";
var cs,ck,cj;
var cw,dg,de,ci;
var au=0;
do
{
cs=bu.charCodeAt(au++);
ck=bu.charCodeAt(au++);
cj=bu.charCodeAt(au++);
cw=cs>>2;
dg=((cs&3)<<4)|(ck>>4);
de=((ck&15)<<2)|(cj>>6);
ci=cj&63;
if(isNaN(ck))
de=ci=64;
else if(isNaN(cj))
ci=64;
bv=bv+bn.charAt(cw)+bn.charAt(dg)+bn.charAt(de)+bn.charAt(ci);
}
while(au<bu.length);
return bv;
}
function Async(bm,ad,ac)
{
this.bz=bm;
this.ad=ad;
this.ac=ac;
this.d=undefined;
this.b=undefined;
this.ag=undefined;
this.bd=undefined;
this.cl=undefined;
this.bt=false;
this.j=undefined;
this.w=0;
}
Async.prototype.setComm=function(d,b)
{
this.d=d;
this.b=b;
}
Async.prototype.setLastState=function(ag)
{
this.ag=ag;
if(this.bt)
{
if(this.ag==3)
{
var responseText=this.d.responseText;
this.ax(responseText.substr(this.w));
this.w=responseText.length;
if(this.w>=this.j)
{
this.d.abort();
this.w=0;
webORB.subscribe(this.b.a,this,this.j);
this.bd=undefined;
this.cl=undefined;
}
}
}
if(this.ag==4)
this.ax(this.d.responseText,this.d.responseXML);
}
Async.prototype.ax=function(responseText,responseXML)
{
if(responseText.length==0)
return;
var bb;
if(this.b.c!=null)
this.b.c.receivedResponse(responseText);
try
{
if(responseXML)
bb=this.b.cn(responseXML);
else
bb=this.b.ao(responseText);
}
catch(e)
{
this.cl=e;
if(this.ad==undefined)
alert("Exception: "+e.description);
else
this.ad.call(this.ac,e);
return;
}
this.bd=bb;
if(this.bz!=undefined)
this.bz.call(this.ac,bb);
}
Async.prototype.getStatus=function()
{
return this.ag;
}
Async.prototype.getResult=function()
{
return this.bd;
}
Async.prototype.getFault=function()
{
return this.cl;
}
Async.prototype.isSuccess=function()
{
if(this.ag!=4)
throw"Cannot call isSuccess until getStatus() returns 4";
return this.bd!=undefined;
}
Async.prototype.enableBufferingMode=function(j)
{
this.j=j;
}
function RecordSet(serverInfo,b)
{
this.serverInfo=serverInfo;
this.b=b;
}
RecordSet.prototype=
{
dk:function()
{
return this.serverInfo;
},
getInitialPage:function()
{
return this.serverInfo.initialData;
},
getInitialPageSize:function()
{
if(this.serverInfo.initialData!=undefined)
return this.serverInfo.initialData.length;
else
return 0;
},
getPageSize:function()
{
return this.serverInfo.pagingSize;
},
getTotalRowCount:function()
{
return this.serverInfo.totalCount;
},
getColumnNames:function()
{
return this.serverInfo.columnNames;
},
getRecords:function(fromRow,rowsToGet,async)
{
var p=new Array(async==undefined?3:4);
p[0]=this.serverInfo.id;
p[1]=Number(fromRow);
p[2]=Number(rowsToGet);
if(async!=undefined)
p[3]=async;
return this.b.handleInvocation("getRecords",this.serverInfo.serviceName,this,p);
},
cleanup:function(async)
{
var p=new Array(async==undefined?1:2);
p[0]=this.serverInfo.id;
if(async!=undefined)
p[1]=async;
return this.b.handleInvocation("release",this.serverInfo.serviceName,this,p);
}
}
function createRecordSet(bs,b)
{
return new RecordSet(bs.serverInfo,b);
}
function Subscriber(b,af,v,l,m)
{
this.b=b;
this.af=af;
this.v=v;
this.l=l;
this.m=m;
this.d=undefined;
this.g=undefined;
}
Subscriber.prototype.send=function(data,recepient)
{
var aa=this.b.createDocument();
var r=aa.createElement("Message");
aa.appendChild(r);
if(recepient!=undefined)
r.setAttribute("deliverTo",recepient);
if(this.v!=undefined)
r.setAttribute("serverName",this.v);
if(this.l!=undefined)
r.setAttribute("channelName",this.l);
r.setAttribute("subscriberID",this.m);
r.appendChild(this.b.u(data,aa));
if(this.d==undefined)
{
this.g=new Async();
this.d=this.b.y(this.g);
this.d.setRequestHeader("weborb-redirect","/messagepost");
this.g.setComm(this.d,this.b);
}
if(aa.xml)
this.d.send(aa.xml);
else
this.d.send(aa);
}
Subscriber.prototype.getSubscriberID=function()
{
return this.m;
}
function MessageServer(eu,df,dw,bz)
{
this.eu=eu;
this.df=df;
this.dw=dw;
this.bz=bz;
this.dn=new Object();
}
MessageServer.connect=function(df,dw,bz,hh)
{
if(hh==undefined)
hh=false;
webORB.eu=new e(ei,'msgsrvr','jsfgw.swf',undefined,hh);
var dm={"lcId":ei};
if(hh)
dm={"lcId":ei,"dofs":"true"};
var ez=i('msgsrvr.swf',1,1,"7,0,0,0",'msgsrvr',dm);
if(!hh)
{
di=document.createElement("DIV");
di.id="_jsfgw_";
di.width=1;
di.height=1;
di.innerHTML=ez;
if(navigator.appName.indexOf("Microsoft")!=-1)
document.appendChild(di);
else
document.body.appendChild(di);
}
else
{
document.write("<div style=\"position:absolute;top:0px;left:0px;width:1px;height:1px;\">"+ez+"</div>");
}
var ee=new MessageServer(webORB.eu,df,dw,bz);
en[df+":"+dw]=ee;
if(!hh)
webORB.eu.call("connect",df,dw);
return ee;
}
MessageServer.prototype.subscribe=function(l,subscribeAs,bz,createChannel,joinSilently)
{
this.dn[l]=bz;
this.eu.call("subscribe",l,subscribeAs,createChannel,joinSilently);
return new Channel(this.eu,l);
}
MessageServer.prototype.handleMessage=function(dh,ds,dv,l,eq)
{
var dr=this.bz;
var es=this.dn[l];
if(es!=null)
dr=es;
if(dr!=undefined)
dr.call(null,dh,ds,dv,l,eq);
}
function Channel(eu,l)
{
this.eu=eu;
this.l=l;
}
Channel.prototype=
{
broadcast:function(dh,ds,deliverToSelf)
{
this.eu.call("broadcast",this.l,dh,ds,deliverToSelf);
},
privateMessage:function(dh,deliverTo,ds)
{
this.eu.call("privateMessage",this.l,dh,deliverTo,ds);
},
getSubscribers:function(subscribeToUpdates)
{
this.eu.call("getSubscribers",this.l,subscribeToUpdates);
},
changeLogicalName:function(newName)
{
this.eu.call("changeLogicalName",this.l,newName);
},
updateSubscriberName:function(newName)
{
this.eu.call("updateSubscriberName",this.l,newName);
},
invokeServer:function(dh,rootName,eq)
{
this.eu.call("invokeServer",this.l,dh,rootName,eq);
}
}
function __gotWOMessage__(df,dw,dh,ds,dv,l,eq)
{
var ex=en[df+":"+dw];
ex.handleMessage(dh,ds,dv,l,eq);
}
function __assemble__(id,eg,em)
{
var cz=new Object();
cz["functionName"]=em;
cz["totalParts"]=eg;
cz["parts"]=new Array();
du[id]=cz;
}
function __addPart__(id,fb)
{
var cz=du[id];
cz["parts"].push(fb);
if(eval(cz["totalParts"])==cz["parts"].length)
{
var dx="";
for(var au=0;au<cz["parts"].length;au++)
dx+=cz["parts"][au];
e.callJS(cz["functionName"],"["+dx+"]");
delete du[id];
}
}
function i(ep,width,height,et,id,dm,an)
{
var q=new String();
var fa=(navigator.appName.indexOf("Microsoft")!=-1)?1:0;
if(fa)
{
q+='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" ';
if(id!=null)
q+='id="'+id+'" ';
q+='codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version='+et+'" ';
q+='width="'+width+'" ';
q+='height="'+height+'">';
q+='<param name="movie" value="'+ep+'"/>';
if(dm!=null)
{
var ew=h12(dm,an);
if(ew.length>0)
q+='<param name="flashvars" value="'+ew+'"/>';
}
q+='</object>';
}
else
{
q+='<embed src="'+ep+'"';
q+=' width="'+width+'"';
q+=' height="'+height+'"';
q+=' type="application/x-shockwave-flash"';
if(this.id!=null)
q+=' name="'+id+'"';
if(dm!=null)
{
var ew=h12(dm,an);
if(ew.length>0)
q+=' flashvars="'+ew+'"';
}
q+=' pluginspage="http://www.macromedia.com/go/getflashplayer">';
q+='</embed>';
}
return q;
}
function h12(dm,an)
{
var dz=new String();
for(var fc in dm)
if(dm[fc]!=null)
dz+=(escape(fc)+'='+encodeURL(dm[fc])+'&');
if(an!=null)
return dz+an;
return dz.substring(0,dz.length-1);
}
function e(ey,fd,dp,dl,hh)
{
e.fpmap[ey]=this;
this.ei=ey;
this.dp=dp;
this.dl=dl;
this.f=new f(false);
this.fe=new Array();
if(hh)
{
if(navigator.appName.indexOf('Internet Explorer')!=-1&&
navigator.platform.indexOf('Win')!=-1&&
navigator.userAgent.indexOf('Opera')==-1)
{
setUpVBCallback(fd);
}
}
}
e.prototype=
{
call:function()
{
this.fe.push(arguments);
if(this.fe.length==1)
this.cv(arguments);
},
cv:function(p)
{
var an=undefined;
if(p.length>1)
{
var ej=new Array();
for(var au=1;au<p.length;++au)
ej.push(p[au]);
an=this.f.cd(ej);
}
var eb='_flash_proxy_'+this.ei;
if(!document.getElementById(eb))
{
var ed=document.createElement("div");
ed.id=eb;
ed.style.position="absolute";
ed.style.posWidth="0px";
ed.style.posHeight="0px";
ed.style.posTop="0px";
ed.style.posLeft="0px";
document.body.appendChild(ed);
}
var ev=document.getElementById(eb);
var dm=new Object();
dm['lcId']=this.ei;
dm['functionName']=p[0];
ev.innerHTML=i(this.dp,1,1,'7,0,0,0',null,dm,an);
}
}
e.callJS=function(command,p)
{
var ec=eval(p);
var eh=e.fpmap[ec.shift()].dl;
var dt=eh?eh[command]:eval(command);
var eo=dt;
if(eh&&(command.indexOf('.')<0))
eo=eh;
dt.apply(eo,ec);
}
e.callComplete=function(ei)
{
var eu=e.fpmap[ei];
if(eu!=null)
{
eu.fe.shift();
if(eu.fe.length>0)
eu.cv(eu.fe[0]);
}
}
function f(dy)
{
this.dy=dy;
}
f.prototype=
{
cd:function(p)
{
var dz=new String();
for(var au=0;au<p.length;++au)
{
switch(typeof(p[au]))
{
case'undefined':
dz+='t'+(au)+'=undf';
break;
case'string':
dz+='t'+(au)+'=str&d'+(au)+'='+p[au];
break;
case'number':
dz+='t'+(au)+'=num&d'+(au)+'='+escape(p[au]);
break;
case'boolean':
dz+='t'+(au)+'=bool&d'+(au)+'='+escape(p[au]);
break;
case'object':
if(p[au]==null)
{
dz+='t'+(au)+'=null';
}
else if(p[au]instanceof Date)
{
dz+='t'+(au)+'=date&d'+(au)+'='+escape(p[au].getTime());
}
else
{
try
{
dz+='t'+(au)+'=xser&d'+(au)+'='+escape(this.cr(p[au]));
}
catch(exception)
{
throw exception;
}
}
break;
}
if(au!=(p.length-1))
{
dz+='&';
}
}
return dz;
},
cr:function(ab)
{
var doc=new Object();
doc.xml='<fp>';
try
{
this.cg(ab,doc,null);
}
catch(exception)
{
throw exception;
}
doc.xml+='</fp>';
return doc.xml;
},
cg:function(ab,doc,n)
{
switch(typeof(ab))
{
case'undefined':
doc.xml+='<undf'+this.cf(n)+'/>';
break;
case'string':
doc.xml+='<str'+this.cf(n)+'>'+this.cy(ab)+'</str>';
break;
case'number':
doc.xml+='<num'+this.cf(n)+'>'+ab+'</num>';
break;
case'boolean':
doc.xml+='<bool'+this.cf(n)+' val="'+ab+'"/>';
break;
case'object':
if(ab==null)
{
doc.xml+='<null'+this.cf(n)+'/>';
}
else if(ab instanceof Date)
{
doc.xml+='<date'+this.cf(n)+'>'+ab.getTime()+'</date>';
}
else if(ab instanceof Array)
{
doc.xml+='<array'+this.cf(n)+'>';
for(var au=0;au<ab.length;++au)
{
this.cg(ab[au],doc,null);
}
doc.xml+='</array>';
}
else
{
doc.xml+='<obj'+this.cf(n)+'>';
for(var fc in ab)
{
if(typeof(ab[fc])=='function')
continue;
this.cg(ab[fc],doc,fc);
}
doc.xml+='</obj>';
}
break;
}
},
cf:function(n)
{
if(name!=null)
return' name="'+n+'"';
return'';
},
cy:function(str)
{
if(this.dy)
return'<![CDATA['+str+']]>';
else
return str.replace(/&/g,'&amp;').replace(/</g,'&lt;');
}
}
function encodeURL(str)
{
if(typeof(str)!='string')
return str;
var s0,au,s,u;
s0="";
for(au=0;au<str.length;au++)
{
s=str.charAt(au);
u=str.charCodeAt(au);
if(s==" ")
s0+="+";
else
{
if(u==0x2a||u==0x2d||u==0x2e||u==0x5f||((u>=0x30)&&(u<=0x39))||((u>=0x41)&&(u<=0x5a))||((u>=0x61)&&(u<=0x7a)))
{
s0=s0+s;
}
else
{
if((u>=0x0)&&(u<=0x7f))
{
s="0"+u.toString(16);
s0+="%"+s.substr(s.length-2);
}
else if(u>0x1fffff)
{
s0+="%"+(0xf0+((u&0x1c0000)>>18)).toString(16);
s0+="%"+(0x80+((u&0x3f000)>>12)).toString(16);
s0+="%"+(0x80+((u&0xfc0)>>6)).toString(16);
s0+="%"+(0x80+(u&0x3f)).toString(16);
}
else if(u>0x7ff)
{
s0+="%"+(0xe0+((u&0xf000)>>12)).toString(16);
s0+="%"+(0x80+((u&0xfc0)>>6)).toString(16);
s0+="%"+(0x80+(u&0x3f)).toString(16);
}
else
{
s0+="%"+(0xc0+((u&0x7c0)>>6)).toString(16);
s0+="%"+(0x80+(u&0x3f)).toString(16);
}
}
}
}
return s0;
}
var du=new Object();
var en=new Object();
var ei=new Date().getTime();
e.fpmap=new Object();
var ez;

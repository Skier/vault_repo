using System;
using System.Web;
using System.Collections;
using Weborb.Util;

namespace Weborb.Examples
{
	public class VisitorInfo
	{
        private int _totalHits = 0;
        private Hashtable _browserTypes = new Hashtable();

        public Hashtable getVisitorsInfo()
        {
            totalHits++;

            HttpRequest request = ThreadContext.currentRequest();

            if( !browserTypes.ContainsKey( request.UserAgent ) )
                browserTypes[ request.UserAgent ] = 0;

            int browserTypeHits = (int) browserTypes[ request.UserAgent ];
            browserTypes[ request.UserAgent ] = browserTypeHits + 1;

            Hashtable result = new Hashtable();            
            result[ "totalHits" ] = totalHits;
            
            foreach( string browserType in browserTypes.Keys )
                result[ browserType ] = browserTypes[ browserType ];

            return result;
        }

        public int totalHits
        {
            set
            {
                _totalHits = value;
            }
            get
            {
                return _totalHits;
            }
        }

        public Hashtable browserTypes
        {
            set
            {
                _browserTypes = value;
            }
            get
            {
                return _browserTypes;
            }
        }
	}
}
